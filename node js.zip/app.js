import express from 'express';
import mongoose from 'mongoose'
import dotenv from 'dotenv'
import { addNewSnack, GetAllSnacks, homePage } from './controllers/snack.controller.js';
dotenv.config()
const app = express()

app.use(express.json()) // req body == json()
app.use(express.urlencoded()) // req.body == form
app.set('view engine', 'ejs') // views
app.use(express.static('public')) // static

app.get('/',homePage)

app.post('/',addNewSnack)
app.get('/snacks', GetAllSnacks)

app.listen(process.env.PORT,()=>{
    console.log('running')
})// server run
mongoose.connect(process.env.MONGODB_CONNECTION).then(
    console.log('connected to db')
).catch((er)=>{
    console.log(er)
})
// mongodb connection