import { Snacks } from "../models/snacks.model.js"

export const addNewSnack = async (req,res) =>{
    const newSnackk = await Snacks.insertOne(req.body) 
    res.json({message:"created",newSnackk })
}

export const GetAllSnacks = async (req,res) =>{
    const snacks = await Snacks.find()
    res.json({snacks})
}
export const homePage = (req,res) =>{
    res.render('home')
}